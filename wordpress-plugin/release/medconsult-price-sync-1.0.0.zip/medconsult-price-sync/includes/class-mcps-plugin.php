<?php

if (!defined('ABSPATH')) {
    exit;
}

final class MCPS_Plugin
{
    public const OPTION_KEY = 'mcps_settings';

    public static function boot(): void
    {
        $content = new MCPS_Content_Model();
        $audit = new MCPS_Audit_Log();
        $client = new MCPS_Supabase_Client(self::settings());

        add_action('init', array($content, 'register_post_type'), 5);
        add_action('acf/init', array($content, 'register_acf_fields'));
        add_action('rest_api_init', array(new MCPS_REST_Controller($client, $content, $audit), 'register_routes'));

        if (is_admin()) {
            (new MCPS_Admin())->register();
        }
    }

    public static function activate(): void
    {
        MCPS_Audit_Log::install();
        (new MCPS_Content_Model())->register_post_type();
        flush_rewrite_rules();
    }

    /** @return array{supabase_url:string,publishable_key:string,allowed_roles:string} */
    public static function settings(): array
    {
        $defaults = array(
            'supabase_url' => '',
            'publishable_key' => '',
            'allowed_roles' => 'price_admin,admin',
        );

        $saved = get_option(self::OPTION_KEY, array());
        return wp_parse_args(is_array($saved) ? $saved : array(), $defaults);
    }
}
